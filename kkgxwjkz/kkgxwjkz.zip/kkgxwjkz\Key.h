#ifndef __Key_h__
#define __Key_h__

#define key2 RB1
#define key3 RB2

void KeyProc(void);
#endif // __Key_h__
